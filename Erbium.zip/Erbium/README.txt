About: Erbium is a security system acting as a second password after you login to your computer. If someone
ever gets your computer password you can always be reasured with Erbium's second password system.

Setup and Info: Before starting up "Erbium.exe" run "Erbium Setup.exe" and setup your email and Password to login to 
Erbium every time you run it. You have always 3 attempts to put in the correct password that you have setup. 
Once Erbium is running and you clicked a 90 second timer will set of if you dont put in the correct password in the 90 
seconds your computer will shut off. If you dont put in the correct password in the 3 attempts your computer will shut off.
Also make a shortcut of erbium.exe and add it to your startup folder so that it will run every 
time you open your computer just remember to put in the password every time you open your computer or else it 
will shut off. You can find the start up folder by pressing "Windows + R" and typing in shell:startup. Put the
shortcut of erbium.exe in there.

Note: You wont be able to put in the password until "Enter Password : " Appears on the screen for that to happen 
you need to press enter.